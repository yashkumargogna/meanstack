module.exports = function($scope){
  console.log("index controller");
}
